import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Scanner;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.Team;
import edu.uab.cs203.network.GymClient;
import edu.uab.cs203.network.GymServer;
import edu.uab.cs203.network.NetworkGym;

public class GServer extends UnicastRemoteObject implements NetworkGym, GymServer {

	private GymClient GClientA;
	private GymClient GClientB;
	private ArrayList<GymClient> clients;
	private Team teama;
	private Team teamb;
	private boolean teamaisready = false;
	private boolean teambisready = false;
	

	protected GServer() throws RemoteException {
		this.clients = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}
	
	
public static void main(String[] arg0) throws RemoteException {
	try {
		GServer server = new GServer();
        Runtime.getRuntime().exec("rmiregistry 10001");
        Registry registry = LocateRegistry.createRegistry(10001);
        registry.bind("GServer", server);
	}catch(Exception e)
	{System.out.println("Error: "+e.toString());
	e.printStackTrace();
	System.exit(0);
		
	}
	System.out.println("Ready to Begin");
	return;
}
//end of slides
	@Override
	public String networkToString() throws RemoteException {
		// TODO Auto-generated method stub
		return this.toString();
	}

	@Override
	public void printMessage(String message) throws RemoteException {
		System.out.println(message);
		
		System.out.println(this.teamaisready+"A");
		System.out.println(this.teambisready+"B");
		if(teamaisready == true && teambisready !=true) {
			GClientA.printMessage("\nPlease wait as Team B connects."+"\n"+"The fight will begin shortly.");
		}else if(teamaisready != true && teambisready ==true) {
			GClientB.printMessage("\nPlease wait as Team A gets ready"+"\n"+"The fight will begin shortly.");
		}else if(teamaisready == true && teambisready ==true) {
			GClientA.printMessage("\nPlease look at Server for commands.");
			GClientB.printMessage("\nPlease look at Server for commands.");
			Scanner f = new Scanner(System.in);
			System.out.println("\n\nAre you ready to begin?");
			String go = f.nextLine();
			if(go.equals("yes")) {
			System.out.println(this.getTeamA().toString());
			System.out.println(this.getTeamB().toString());
			}else {
				System.exit(0);
			}
			System.out.println("\nHow many rounds would you like to do.");
			int rounds = f.nextInt();
			this.fight(rounds);
			
		}
		
	}

	@Override
	public void registerClientA(String host, int port, String registryName) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println(host+port+registryName);
		
		try {
        this.GClientA  = (GymClient) LocateRegistry.getRegistry(host, port).lookup(registryName);
        this.clients.add(this.GClientA);
        this.GClientA.printMessage("Client A registered.");
        this.setTeamAReady(true);
		}catch(Exception e) {
			System.out.println("Error: "+e.toString());
			e.printStackTrace();
		}
	}

	@Override
	public void registerClientB(String host, int port, String registryName) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println(host+port+registryName);
		
		try {
        this.GClientB  = (GymClient) LocateRegistry.getRegistry(host, port).lookup(registryName);
        this.clients.add(this.GClientB);
        this.GClientB.printMessage("Client B registered.");
        this.setTeamBReady(true);
		}catch(Exception e) {
			System.out.println("Error: "+e.toString());
			e.printStackTrace();
		}
	}
		
	

	@Override
	public void setTeamA(Team teamA) throws RemoteException {
		this.teama = teamA;
		
	}

	@Override
	public void setTeamAReady(boolean ready) throws RemoteException {
		// TODO Auto-generated method stub
		this.teamaisready = ready;
	}

	@Override
	public void setTeamB(Team teamB) throws RemoteException {
	this.teamb = teamB;
		
	}

	@Override
	public void setTeamBReady(boolean ready) throws RemoteException {
		// TODO Auto-generated method stub
		this.teambisready = ready;
	}
	@Override
	public void executeTurn() {
		try {
			this.GClientA.networkTick();
			this.GClientB.networkTick();
			Objectmon teama = GClientA.nextObjectmon();
			Objectmon teamb = GClientB.nextObjectmon();
			
			if(teama == null &&teamb== null) {
				return;
			}
			this.GClientB.networkApplyDamage(teama, teamb,teama.nextAttack().getDamage(teamb));
			if(teamb.isFainted()==true) {
				return;	}
			this.GClientA.networkApplyDamage(teamb, teama, teamb.nextAttack().getDamage(teama));
			return;
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	@Override
	public void fight(int arg0) {
		// TODO Auto-generated method stub
        int count = 0;
        while(arg0 != count) {
        	if(this.getTeamA().canFight() && this.getTeamB().canFight()) {
        		this.executeTurn();
        		count ++;
        		if(this.getTeamA().canFight() && this.getTeamB().canFight()) {
            		this.broadcastMessage("Team A wint after "+count+" rounds.");
            		count = arg0;
            	}else if(this.getTeamB().canFight() && this.getTeamA().canFight()){
            		this.broadcastMessage("Team B wint after "+count+" rounds.");
            		count = arg0;
            	}
       
        }
        	
        	if(this.getTeamA().canFight() && this.getTeamB().canFight()) {
        		this.broadcastMessage("Draw");
        	}
        return;

        
    }
		
	}
	@Override
	public GymClient getClientA() {
		// TODO Auto-generated method stub
		
		return this.GClientA;
	}
	@Override
	public GymClient getClientB() {
		// TODO Auto-generated method stub

		return this.GClientB;
	}
	@Override
	public Team getTeamA() {
		// TODO Auto-generated method stub
		Team tz = null;
		try {
			tz = GClientA.getTeam();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tz;
	}
	@Override
	public Team getTeamB() {
		// TODO Auto-generated method stub
		Team tz = null;
		try {
			tz = GClientB.getTeam();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tz;
	}

}
