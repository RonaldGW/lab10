import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;
import edu.uab.cs203.Team;
import edu.uab.cs203.lab05.BasicTeam;
import edu.uab.cs203.lab09.Hashmon;
import edu.uab.cs203.network.GymClient;
import edu.uab.cs203.network.GymServer;
import edu.uab.cs203.network.NetworkGym;

public class GClientA implements Serializable, GymClient {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Team<Objectmon> team = new BasicTeam<>("teama", 6);


	public GClientA() {
		// TODO Auto-generated constructor stub
		super();
	}
	GServer client;


	public static void main(String[] args) throws RemoteException  {
		GClientA clienta = new GClientA();
		 
		String hosta = "localhost";
		int porta = 45625;
		clienta.CreateTeam();
		String bind ="//"+"0.0.0.0"+":"+45625+"/clienta";
		try {

			Registry regisrty = LocateRegistry.createRegistry(porta);
			
			System.out.println("Server should be up for A");
		} catch (Exception e) {
			System.out.println("System Error: "+e.toString());
			e.printStackTrace();
			System.exit(0);

		}
		
			try {
				Naming.bind(bind, clienta);
			} catch (MalformedURLException | AlreadyBoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("We are getting there for A");
		
			
		
		

		

		
		
		System.out.print("ready to receive tasks");
		
		String host = "localhost";
		//String host = "box01";
		int port = 1091;
		String connection = "//"+host+":"+port+"/ser";
		GymServer stub = null;
		//System.setSecurityManager(new RMISecurityManager());
		//String hoste = (args.length < 1) ? null : args[0];
		try {
			//Registry registry = LocateRegistry.getRegistry(hoste,4526);
			//GServer stub =(GServer) registry.lookup("GServer");
			//Registry registry = LocateRegistry.getRegistry(host,9001);
			//GymServer stub =(GymServer)registry.lookup("computeServer");
			System.out.println("Dat Way: "+connection);
			stub = (GymServer)Naming.lookup(connection);
			System.out.println("Connected");
			//stub.printMessage("A Client Connected");
			stub.registerClientA(hosta, porta,"ser");
			//stub.printMessage("Begin");
		} catch (Exception e) {
			System.out.println("Error: "+e.toString());
			e.printStackTrace();
			System.exit(0);
		}
	}

	@Override
	public Team<Objectmon> getTeam() throws RemoteException {
		return this.team;
	}

	@Override
	public Objectmon networkApplyDamage(Objectmon arg0, Objectmon arg1, int arg2) throws RemoteException {
		arg1.setHp(arg1.getHp()-arg2);
		return arg1;
	}

	@Override
	public void networkTick() throws RemoteException {
		this.team.tick();

	}

	@Override
	public Objectmon nextObjectmon() throws RemoteException {
		for(int i=0; i<team.size(); i++) {
			if(((Objectmon) team.get(i)).isFainted()!= true) {
				return (Objectmon) team.get(i);
			}
		}
		return null;

	}

	@Override
	public void printMessage(String arg0) throws RemoteException {
		System.out.print(arg0);
		Scanner sk = new Scanner(System.in);

		System.out.println("Are you ready?");
		String begin = sk.nextLine();
		if(begin.equals("yes")) {
			client.setTeamAReady(true);
		}
		System.out.println("Say Go.");
		String hopes = sk.nextLine();
		if(hopes.equals("go")) {
			client.broadcastMessage("TEST from A");
		}else {
			this.printMessage("Team B is not ready");
		}
	}

	@Override
	public void setTeam(Team arg0) throws RemoteException {
		team = arg0;
		return;

	}
	public void CreateTeam() throws RemoteException {
	    for(int i=0;i<=this.getTeam().getMaxSize();i++) {
	        Hashmon bob=new Hashmon(ObjectmonNameGenerator.nextName());
	        team.add(bob);
	    }}
}