import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.Team;
import edu.uab.cs203.network.GymClient;
import edu.uab.cs203.network.GymServer;
import edu.uab.cs203.network.NetworkGym;

public class GServer  extends UnicastRemoteObject implements GymServer, NetworkGym {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected GServer() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	
	private String message;
	private boolean Bisready;
	private boolean Aisready;
	private GymClient ClientA;
	private GymClient ClientB;
	//side stuff
	public static void main(String[] args) throws RemoteException {
		int port = 1091;
		GServer ser = new GServer();
		try {
			//Registry registry = LocateRegistry.getRegistry();
			//registry.bind("GServer", ser);
			LocateRegistry.createRegistry(port);
			System.out.println("Server should be up");
		} catch (Exception e) {
			System.out.println("System Error: "+e.toString());
			e.printStackTrace();
			System.exit(0);
			
		}
		String hostname = "0.0.0.0";
		
		String bind ="//"+hostname+":"+port+"/ser";
		
		try {
			Naming.bind(bind, ser);
			System.out.println("We are getting there");
		} catch (MalformedURLException | AlreadyBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("ready to receive tasks");
		return;
	}
//end of slides
	@Override
	public String networkToString() throws RemoteException {
		// TODO Auto-generated method stub
		return this.toString();
	}

	@Override
	public void printMessage(String message) throws RemoteException {
		this.message = message;
				System.out.println(message);	
				this.ClientA.printMessage("From Server");
	}

	@Override
	public void registerClientA(String host, int port, String registryName) throws RemoteException {
		// TODO Auto-generated method stub
		GClientA clienta = new GClientA();
		String bind ="//"+"0.0.0.0"+":"+45625+"/clienta";
		
		
		clienta.printMessage("From Server");
		
	}

	@Override
	public void registerClientB(String host, int port, String registryName) throws RemoteException {
		// TODO Auto-generated method stub
		GymClient serv;
		try {
			
			serv = (GymClient)LocateRegistry.getRegistry(host,port).lookup(registryName);
	
			System.out.println(registryName+"Sup, All active here.");
			this.ClientB = serv;
			
		} catch(Exception e) {
			System.out.println("Error: "+e.toString());
			e.printStackTrace();
		}
		return;
		
	}

	@Override
	public void setTeamA(Team teamA) throws RemoteException {
		
		
	}

	@Override
	public void setTeamAReady(boolean ready) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(ready == true) {
			this.Aisready = true;
		}else {
			this.Aisready = false;
		}
		return;
	}

	@Override
	public void setTeamB(Team teamB) throws RemoteException {
	
		
	}

	@Override
	public void setTeamBReady(boolean ready) throws RemoteException {
		// TODO Auto-generated method stub
		if(ready == true) {
			this.Aisready = true;
		}else {
			this.Aisready = false;
		}
		return;
	}
	@Override
	public void executeTurn() {
		// TODO Auto-generated method stub
		
		try {
			this.getClientA().getTeam().tick();
			this.getClientB().getTeam().tick();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Objectmon teama = null;
		Objectmon teamb = null;
		try {
			teama = this.getClientA().getTeam().nextObjectmon();
			teamb = this.getClientB().getTeam().nextObjectmon();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(teama != null) {
			teama.nextAttack();
		}
		if(teamb != null) {
			teamb.nextAttack();
		}
		
	}
	@Override
	public void fight(int arg0) {
		// TODO Auto-generated method stub
        int count = 0;
        while(arg0 != count) {
        	if(this.getTeamA().canFight() && this.getTeamB().canFight()) {
        		this.executeTurn();
        		count ++;
        		if(this.getTeamA().canFight() && this.getTeamB().canFight()) {
            		this.broadcastMessage("Team A wint after "+count+" rounds.");
            		count = arg0;
            	}else if(this.getTeamB().canFight() && this.getTeamA().canFight()){
            		this.broadcastMessage("Team B wint after "+count+" rounds.");
            		count = arg0;
            	}
       
        }
        	
        	if(this.getTeamA().canFight() && this.getTeamB().canFight()) {
        		this.broadcastMessage("Draw");
        	}
        return;

        
    }
		
	}
	@Override
	public GymClient getClientA() {
		// TODO Auto-generated method stub
		
		return this.getClientA();
	}
	@Override
	public GymClient getClientB() {
		// TODO Auto-generated method stub

		return this.getClientB();
	}
	@Override
	public Team getTeamA() {
		// TODO Auto-generated method stub
		try {
			return this.getClientA().getTeam();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}return null;
	}
	@Override
	public Team getTeamB() {
		// TODO Auto-generated method stub
		try {
			return this.getClientB().getTeam();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}return null;
	}

}
