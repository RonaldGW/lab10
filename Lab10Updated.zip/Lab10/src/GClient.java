import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.List;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;
import edu.uab.cs203.Team;
import edu.uab.cs203.lab09.Hashmon;
import edu.uab.cs203.network.GymClient;

public class GClient implements GymClient, Serializable{



	private static final long serialVersionUID = 1L;
	private String message;
	private Team teamA;


	@Override
	public Team<Objectmon> getTeam() throws RemoteException {
		return null;
	}

	@Override
	public Objectmon networkApplyDamage(Objectmon from, Objectmon to, int damage) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void networkTick() throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public Objectmon nextObjectmon() throws RemoteException {
		for(int i =0; i <= teamA.size();i++) { 
			if (teamA.canFight() == true ) {
				return ;
			}
		}
		return null;
	}

	@Override
	public void printMessage(String message) throws RemoteException {
		this.message = message;
	}

	@Override
	public void setTeam(Team teamA) throws RemoteException {
		int i = 6;
		for (int j = 0; j <= i; j++) {
			getTeam().add(new Hashmon(ObjectmonNameGenerator.nextName()));
			getTeam().add(new Hashmon(ObjectmonNameGenerator.nextName()));}
	}

}

