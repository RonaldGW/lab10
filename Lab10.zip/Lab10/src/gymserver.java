import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import edu.uab.cs203.Team;
import edu.uab.cs203.network.GymClient;
import edu.uab.cs203.network.GymServer;
import edu.uab.cs203.network.NetworkGym;

public class gymserver extends UnicastRemoteObject implements GymServer, Serializable,NetworkGym {

	private static final long serialVersionUID = 1L;


	protected gymserver() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String networkToString() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void printMessage(String arg0) throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void registerClientA(String arg0, int arg1, String arg2) throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void registerClientB(String arg0, int arg1, String arg2) throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setTeamA(Team arg0) throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setTeamAReady(boolean arg0) throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setTeamB(Team arg0) throws RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setTeamBReady(boolean arg0) throws RemoteException {
		// TODO Auto-generated method stub

	}


	@Override
	public void executeTurn() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void fight(int arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public GymClient getClientA() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public GymClient getClientB() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Team getTeamA() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Team getTeamB() {
		// TODO Auto-generated method stub
		return null;
	}
	 public static void main(String[] args) {
		    try {
		      Runtime.getRuntime().exec("rmiregistry 9999");
		      Registry registry = LocateRegistry.createRegistry(9999);
		     gymserver GymServer = new gymserver();
		      

		      registry.bind("Gym", GymServer);

		    } catch (Exception e) {
		      e.printStackTrace(System.err);
		      System.exit(-1);
		    }

		    System.out.println("Ready to Battle!");
		    return;
		  }
		}


