import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFileChooser;

import edu.uab.cs203.ObjectdexEntry;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;
import edu.uab.cs203.Team;
import edu.uab.cs203.attacks.AbstractAttack;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.effects.AbstractStatusEffect;
import edu.uab.cs203.effects.StatusEffect;
import edu.uab.cs203.lab05.BasicTeam;
import edu.uab.cs203.lab08.BadPoisonAttack;
import edu.uab.cs203.lab08.FreezingAttack;
import edu.uab.cs203.lab08.ParalyzingAttack;
import edu.uab.cs203.lab08.PoisonAttack;
import edu.uab.cs203.lab08.Poisoned;
import edu.uab.cs203.lab08.SleepAttack;
import edu.uab.cs203.lab08.Statusmon;
import edu.uab.cs203.lab09.Hashmon;
import edu.uab.cs203.network.GymClient;
import edu.uab.cs203.network.GymServer;
import edu.uab.cs203.network.NetworkGym;

public class GClientA extends UnicastRemoteObject implements Serializable, GymClient {



	protected GClientA() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	private Team<Objectmon> teama;
	private GymServer server;
	private NetworkGym servera;
	public static void main (String[] arg0) throws RemoteException {


		try {
			int clientPort = 9998;
			int serverPort = 10001;
			String serverHost = "localhost";
			GymClient GClientA = new GClientA();
			Runtime.getRuntime().exec("rmiregistry " + clientPort);
			Registry registry = LocateRegistry.createRegistry(clientPort);
			registry.bind("GClientA", GClientA);
			System.out.println("one");
			Registry serverRegistry = LocateRegistry.getRegistry(serverHost, serverPort);
			GymServer server = (GymServer) serverRegistry.lookup("GServer");
			System.out.println("two");
			server.registerClientA("localhost", clientPort, "GClientA");
			System.out.println("three");
			server.printMessage("Clinet A");
		}catch(Exception e) {
			System.out.println("Trace back:");
			e.printStackTrace();
		}
	}

	@Override
	public Team getTeam() throws RemoteException {
		return this.teama;

	}

	@Override
	public Objectmon networkApplyDamage(Objectmon arg0, Objectmon arg1, int arg2) throws RemoteException {
		arg1.setHp(arg1.getHp()-arg2);
		
		return arg1;
	}

	@Override
	public void networkTick() throws RemoteException {
		this.teama.tick();

	}

	@Override
	public Objectmon nextObjectmon() throws RemoteException {
		for(int i=0; i<teama.size(); i++) {
			if(((Objectmon) teama.get(i)).isFainted()!= true) {
				return (Objectmon) teama.get(i);
			}
		}
		return null;

	}

	@Override
	public void printMessage(String arg0) throws RemoteException {
		System.out.println(arg0);
	}

	@Override
	public void setTeam(Team arg0) throws RemoteException {
		this.teama = arg0;

	}

	}

