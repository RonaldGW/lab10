import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import edu.uab.cs203.ObjectdexEntry;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;
import edu.uab.cs203.Team;
import edu.uab.cs203.attacks.AbstractAttack;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.lab05.BasicTeam;
import edu.uab.cs203.lab06.FileTeam;
import edu.uab.cs203.lab08.BadPoisonAttack;
import edu.uab.cs203.lab08.FreezingAttack;
import edu.uab.cs203.lab08.Lab08StatusGym;
import edu.uab.cs203.lab08.ParalyzingAttack;
import edu.uab.cs203.lab08.PoisonAttack;
import edu.uab.cs203.lab08.SleepAttack;
import edu.uab.cs203.lab08.Statusmon;
import edu.uab.cs203.lab09.Hashmon;
import edu.uab.cs203.network.GymClient;
import edu.uab.cs203.network.GymServer;
import edu.uab.cs203.network.NetworkGym;

public class GServer extends UnicastRemoteObject implements NetworkGym, GymServer {
	
	private GymClient GClientA;
	private GymClient GClientB;
	private ArrayList<GymClient> clients;
	private Team<Objectmon> teama;
	private Team<Objectmon> teamb;
	private boolean teamaisready = false;
	private boolean teambisready = false;
	
	
	
	protected GServer() throws RemoteException {
		this.clients = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] arg0) throws RemoteException {
		
		try {
			GServer server = new GServer();
			Runtime.getRuntime().exec("rmiregistry 10001");
			Registry registry = LocateRegistry.createRegistry(10001);
			registry.bind("GServer", server);
		}catch(Exception e)
		{System.out.println("Error: "+e.toString());
		e.printStackTrace();
		System.exit(0);

		}
		System.out.println("Ready to Begin");
		return;
	}
	//end of slides
	@Override
	public String networkToString() throws RemoteException {
		// TODO Auto-generated method stub
		return this.toString();
	}

	@Override
	public void printMessage(String message) throws RemoteException {
		System.out.println(message);
		if(teamaisready == true && teambisready !=true) {
			GClientA.printMessage("\nPlease wait as Team B connects."+"\n"+"The fight will begin shortly.");
		}else if(teamaisready != true && teambisready ==true) {
			GClientB.printMessage("\nPlease wait as Team A gets ready"+"\n"+"The fight will begin shortly.");
		}else if(teamaisready == true && teambisready ==true) {
			GClientA.printMessage("\nPlease look at Server for commands.");
			GClientB.printMessage("\nPlease look at Server for commands.");
			Scanner f = new Scanner(System.in);
			System.out.println("\n\nAre you ready to begin?");
			String go = f.nextLine();
			if(go.equals("yes")) {
				System.out.println(this.getTeamA().toString());
				GClientA.setTeam(teama);
				GClientB.setTeam(teamb);
				System.out.println(this.getTeamB().toString());
			}else {
				System.exit(0);
			}
			System.out.println("\nHow many rounds would you like to do.");
			int rounds = f.nextInt();
			this.fight(rounds);

		}

	}

	@Override
	public void registerClientA(String host, int port, String registryName) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println(host+port+registryName);

		try {
			this.GClientA  = (GymClient) LocateRegistry.getRegistry(host, port).lookup(registryName);
			this.clients.add(this.GClientA);
			this.GClientA.printMessage("Client A registered.");
			this.setTeamAReady(true);
		}catch(Exception e) {
			System.out.println("Error: "+e.toString());
			e.printStackTrace();
		}
	}

	@Override
	public void registerClientB(String host, int port, String registryName) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println(host+port+registryName);

		try {
			this.GClientB  = (GymClient) LocateRegistry.getRegistry(host, port).lookup(registryName);
			this.clients.add(this.GClientB);
			this.GClientB.printMessage("Client B registered.");
			this.setTeamBReady(true);
		}catch(Exception e) {
			System.out.println("Error: "+e.toString());
			e.printStackTrace();
		}
	}



	@Override
	public void setTeamA(Team teamA) throws RemoteException {
		GClientA.setTeam(teamA);
		this.teama = teamA;

	}

	@Override
	public void setTeamAReady(boolean ready) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println("File Path:");
		JButton tab = new JButton();
		JFileChooser file = new JFileChooser();
		file.setDialogTitle("Select File Path:");
		file.showOpenDialog(tab);
		String path = file.getSelectedFile().getAbsolutePath();
		Scanner no = new Scanner(System.in);
		System.out.println("How many Hashmon on your team?");
		int rounds = no.nextInt();
		teama = new BasicTeam<>("Team A", rounds);
		try {
			Hashmon.loadObjectdex(path);
			for(int i=0;i<=rounds-1;i++) {
				teama.add(new Statusmon(ObjectmonNameGenerator.nextName()));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		this.setTeamA(teama);
		GClientA.setTeam(teama);
		this.teamaisready = ready;
	}



	@Override
	public void setTeamB(Team teamB) throws RemoteException {
		GClientB.setTeam(teamB);
		this.teamb = teamB;


	}

	@Override
	public void setTeamBReady(boolean ready) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println("File Path:");
		JButton tab = new JButton();
		JFileChooser file = new JFileChooser();
		file.setDialogTitle("Select File Path:");
		file.showOpenDialog(tab);
		String path = file.getSelectedFile().getAbsolutePath();
		Scanner no = new Scanner(System.in);
		System.out.println("How many Hashmon on your team?");
		int rounds = no.nextInt();
		teamb = new BasicTeam<>("Team B", rounds);
		
		try {
			Hashmon.loadObjectdex(path);
			for(int i=0;i<=rounds-1;i++) {
				teamb.add(new Hashmon(ObjectmonNameGenerator.nextName()));
				 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		this.setTeamB(teamb);	
		GClientB.setTeam(teamb);
		this.teambisready = ready;

	}
	@Override
	public void executeTurn() {
		try {
			AbstractAttack att = null;
			this.GClientA.networkTick();
			this.GClientB.networkTick();
			Objectmon at = teama.nextObjectmon();
			Objectmon df = teamb.nextObjectmon(); 
			System.out.println(at.getName()+":"+at.getHP());
			System.out.println(at.getName()+":"+df.getHP());
			String effect = at.getAttacks().get(0).toString();
			
			int ia = -1;
			for(Objectmon a: teama) {
				ia++;
				if(a.equals(at)) {
					if(effect.equals("Poison Attack")) {
						att = new PoisonAttack(at, "Poison Attack");
						System.out.println("PA");
					}else if(effect.equals("BadPoison")) {
						att = new BadPoisonAttack(at,"Bad Poison Attack");
					}else if(effect.equals("Basic")) {
						att = new BasicAttack(at,"Basic Attack");
						System.out.println("BA");
					}else if(effect.equals("Sleep")) {
						att = new SleepAttack(at,"Sleep Attack");
						System.out.println("SA");
					}else if(effect.equals("Paralyzing")) {
						att = new ParalyzingAttack(at,"Paralyzing Attack");
						System.out.println("PA");
					}else if(effect.equals("Freezing")) {
						att = new FreezingAttack(at,"Freezing Attack");
						System.out.println("F");
					}
					System.out.println(at.getAttacks().get(0).getCooldownRemaining());
					Objectmon k = GClientA.networkApplyDamage(at, df, at.nextAttack().getDamage(at));
					teama.set(ia, k);
					this.setTeamA(teama);
				}
			}
			int ib = -1;
			for(Objectmon z: teamb) {
				ib++;
				if(z.equals(df)) {
					Objectmon l = GClientB.networkApplyDamage(df, at, df.nextAttack().getDamage(df));
					teamb.set(ib, l);
					this.setTeamB(teamb);
				}
			}

		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}
	@Override
	public void fight(int arg0) {
		// TODO Auto-generated method stub
		Lab08StatusGym gym = new Lab08StatusGym(teama,teamb);
		gym.fight(arg0);
	}
	@Override
	public GymClient getClientA() {
		// TODO Auto-generated method stub

		return this.GClientA;
	}
	@Override
	public GymClient getClientB() {
		// TODO Auto-generated method stub

		return this.GClientB;
	}
	@Override
	public Team getTeamA() {
		// TODO Auto-generated method stub

		return teama;
	}
	@Override
	public Team getTeamB() {
		// TODO Auto-generated method stub

		return teamb;
	}

}
